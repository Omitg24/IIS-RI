package uo.ri.cws.application.service.mechanic.crud.command;

import java.util.List;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;

public class FindAllMechanics {

	public List<MechanicDto> execute() {
		
		return null;
	}

}
