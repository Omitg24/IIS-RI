package uo.ri.cws.domain;

public class Client {
	private String dni;
	private String name;
	private String surname;
	private String email;
	private String phone;
	private Address address;

}

