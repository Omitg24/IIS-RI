package uo.ri.cws.domain;

public class Cash extends PaymentMean {

}
