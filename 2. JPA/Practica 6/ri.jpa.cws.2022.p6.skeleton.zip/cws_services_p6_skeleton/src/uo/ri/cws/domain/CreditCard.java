package uo.ri.cws.domain;

import java.time.LocalDate;

public class CreditCard extends PaymentMean {
	private String number;
	private String type;
	private LocalDate validThru;

}
