package uo.ri.cws.application.service.workorder;

/**
 * This service is intended to be used by the Mechanic
 * It follows the ISP principle (@see SOLID principles from RC Martin)
 */
public interface CloseWorkOrderService {

	// ...

}
