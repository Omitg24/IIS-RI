package uo.ri.cws.application.ui.manager.action.contractManagement;

import menu.Action;
import uo.ri.cws.application.business.BusinessException;

/**
 * Clase qe borra un contrato
 * 
 * @author Carlos
 *
 */
public class DeleteContractAction implements Action {

	/**
	 * Borra el contrato dado un id pasado por consola
	 */
	@Override
	public void execute() throws BusinessException {

//		String idContract = Console.readString("Contract identifier ");
//
//		Console.println("Contract no longer exists");

	}
}
