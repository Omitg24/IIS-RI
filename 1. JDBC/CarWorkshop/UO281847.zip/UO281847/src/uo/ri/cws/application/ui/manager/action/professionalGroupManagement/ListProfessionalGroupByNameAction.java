package uo.ri.cws.application.ui.manager.action.professionalGroupManagement;

import menu.Action;
import uo.ri.cws.application.business.BusinessException;

public class ListProfessionalGroupByNameAction implements Action {

	@Override
	public void execute() throws BusinessException {

//		String name = Console.readString("Professional group name ");
//
//		Printer.printProfessionalGroup(result);

	}

}
