package uo.ri.cws.application.ui.manager.action.professionalGroupManagement;

import menu.Action;

public class DeleteProfessionalGroupAction implements Action {

	@Override
	public void execute() throws Exception {
//
//		String name = Console.readString("Professional group name ");
//
//		Console.print("Professional group successfully deleted");
	}

}
